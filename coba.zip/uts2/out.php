<?php
echo "Anda sudah Keluar!"
?>