<!DOCTYPE html>
<html lang="en">

<body>
    <h2 style="color: red;">SELESAI!</h2>
</body>
</html>