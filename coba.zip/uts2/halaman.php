<?php
require "function.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
   <div class="menu">
        <center><h3 style="background-color: yellow; width: 520px; height: 25px;"><center>SISTEM AKADEMIK POLITEKNIK NEGERI CILACAP</center></h3></center>

        <h4>MENU UTAMA</h4>
        <ol>
            <li>
                <div><a href="inputdata.php">Input Data Mata Kuliah</a></div>
            </li>
            <li>
                <div><a href="hapus.php">Hapus Data Matkul</a></div>
            </li>
            <li>
                <div><a href="cetak.php">Cetak Data Matkul</a></div>
            </li>
            <li>
                <div><a href="out.php">Keluar</a></div>
            </li>
        </ol>
        <p>Lihat <b><a href="kategori.html">Kategori</a></b></p>
   </div> 
</body>
</html>
